USE TEST;
CREATE TABLE dasleads
(
SNO int not null,
name varchar(30),
designation varchar(30)
)