USE SOURCE;

CREATE TABLE `details` (
  `name` varchar(10) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `salary` decimal(8,0) DEFAULT NULL
);
