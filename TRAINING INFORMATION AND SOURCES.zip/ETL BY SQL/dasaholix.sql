CREATE DATABASE TEST;

USE TEST;

CREATE TABLE dasaholix
(
name varchar(30),
age int,
nickname varchar(30)
)

