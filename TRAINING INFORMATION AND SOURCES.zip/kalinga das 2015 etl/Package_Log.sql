CREATE TABLE [DBO].[PACKAGE_LOG](
                        [PACKAGE_LOG_ID] [INT] IDENTITY(1,1),
                        [PACKAGE_STATUS] [VARCHAR](100),
                        [PACKAGE_START_DATE] [DATETIME],
                        [PACKAGE_END_DATE] [DATETIME],
			[ROWCOUNT] INT,
                        [CREATED_BY] [VARCHAR](100),
                        [CREATED_DATE] [DATETIME],
                        [MODIFIED_BY] [VARCHAR](100),
                        [MODIFIED_DATE] [DATETIME]
                        CONSTRAINT [PK_PACKAGE_LOG] PRIMARY KEY CLUSTERED ([PACKAGE_LOG_ID] ASC)
            )
