CREATE TABLE [DBO].[TASK_LOG](
                        [TASK_LOG_ID] [INT] IDENTITY(1,1) 
                        [TASK_NAME] [varchar](255) ,
                        [TASK_START_TIME] [DATETIME],
                        [DESCRIPTION] [varchar](1000) NULL,
                        [EVENT_HANDLER_NAME] [varchar](20) NULL,
                        [CREATED_BY] [VARCHAR](100),
                        [CREATED_DATE] [DATETIME]	,
                        [MODIFIED_BY] [VARCHAR](100),
                        [MODIFIED_DATE] [DATETIME],
                        CONSTRAINT [PK_PACKAGE_TASK_LOG] PRIMARY KEY CLUSTERED ([PACKAGE_TASK_LOG_ID] ASC)
            )

